#include<iostream>
using namespace std;
#include<vector>


#define max(a,b) a>b?a:b;
#define min(a,b) a<b?a:b;
// O(n)  O(1)
 class Solution
 {
 public:
	 int maxProfit(vector<int>&prices)
	 {
		 int sum=0;
		 for(int i=1; i<prices.size(); i++)
		 {
			 int diff=prices[i]-prices[i-1];
			 if(diff>0){
				 sum+=diff;cout<<"666"<<endl;
			 }
		 }
		 return sum;
	 }
 };



int main()
{
	 
	vector<int>v;
	v.push_back(1); 	v.push_back(4); 	v.push_back(5); 	v.push_back(1); 	v.push_back(6);
	Solution s;
	cout<<s.maxProfit(v)<<endl;

	return 0;
}

