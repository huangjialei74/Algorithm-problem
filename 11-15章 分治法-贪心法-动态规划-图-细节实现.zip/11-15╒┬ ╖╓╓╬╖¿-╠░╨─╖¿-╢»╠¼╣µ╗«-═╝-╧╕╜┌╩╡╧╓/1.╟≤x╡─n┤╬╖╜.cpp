#include<iostream>
using namespace std;


//���ַ���x^n=x^n/2��x^n/2��x^n%2



//���ַ�, x^n= x^{n/2}* x^{n/2}* x^{n\%2} 
// O(logn)  O(1)
class Solution
{
public:
	double myPow(double x,int n)
	{
		if(n<0)
			return 1.0/power(x,-n);
		else
			return power(x,n);
	}
private:
	double power(double x,int n)
	{
		if(n==0)
			return 1;
		double v=power(x,n/2);//�ݹ�
		if(n&0x1)//��0��1
			return v*v*x; 
		else
			return v*v;
	}
};
 


int main()
{
	 

	return 0;
}

