#include<iostream>
using namespace std;


#include<vector>
#include<string>
#define min(a,b)((a)<=(b)?(a):(b))
#define max(a,b)((a)>=(b)?(a):(b))


// O(n)  O(n)
class Solution
{
public:
	int maxProfit(vector<int>&prices)
	{
		if(prices.size()<2)
			return 0;
		const int n=prices.size();
		vector<int>f(n,0); 
		vector<int>g(n,0);
		int  i,valley,peak;
		for( i=1,valley=prices[0]; i<n; ++i)
		{
			valley=min(valley,prices[i]);
			f[i]=max(f[i-1],prices[i]-valley);
		}
		for( i=n-2,peak=prices[n-1]; i>=0; --i)
		{
			peak=max(peak,prices[i]);
			g[i]=max(g[i],peak-prices[i]);
		}
		int max_profit=0;
		for( i=0;i<n; ++i)
			max_profit=max(max_profit,f[i]+g[i]);
		return max_profit;
	}
};
















int main()
{
	 

	return 0;
}

