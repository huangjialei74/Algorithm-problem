#include<iostream>
using namespace std;


#include<vector>

#define max(a,b) a>=b?a:b;

int min(int a,int b)
{
	return a<b ?a:b;
}

//���� O(n)  O(1)
class Solution
{
public:
	int maxSubArray(vector<int>&nums)
	{
		int result=INT_MIN, f=0;
		for(int i=0; i<nums.size(); ++i)
		{
			f=max(f+nums[i],nums[i]);//fΪǰ�������
			result=max(result,f);
		}
		return result;
	}
	int maxSubArray(vector<int>&nums)
	{
		int result=INT_MIN, f=0;
		for(int i=0; i<nums.size(); i++)
		{
			f=max(f+nus[i],nums[]);
		}
	}
};

 // O(n) O(n)
class Solution2
{
public:
	int maxSubArray(vector<int>&A)
	{
		return mcss(A.begin(),A.end());
	}
private:
	 template<typename Iter>
		 static int mcss(Iter begin,Iter end)
	 {
		 int result, cur_min; 
		 const int n=distance(begin, end);
		 int *sum = new int[n+1];
		 //ǰn���
		 sum[0]=0;
		 result=INT_MIN;
		 cur_min=sum[0];
        int i;
		 for( i=1; i<=n; i++)
		 {
			 sum[i]=sum[i-1]+ *(begin+i-1);
		 }
		 for(  i=1; i<=n; i++)
		 {
			 result=max(result, sum[i]-cur_min);
			 cur_min=min(cur_min, sum[i]);
		 }
		 delete[]sum;
		 return result;
	 }
};




int main()
{
	vector<int> v;
	v.push_back(1); v.push_back(1); v.push_back(-4); v.push_back(3); v.push_back(-1);
	 
    Solution2 s;
    cout<<s.maxSubArray(v)<<endl;
	return 0;
}

